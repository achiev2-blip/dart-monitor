/**
 * DART 공시 모니터 — Node.js 로컬 서버 v3.5
 * 
 * 기능:
 *  - DART API 프록시 (CORS 해소)
 *  - Gemini AI 프록시
 *  - 뉴스 RSS 수집 (직접 접근, 프록시 불필요)
 *  - 증권사 리포트 수집 (WiseReport + 미래에셋 직접 + 네이버 금융)
 *  - 텔레그램 전송
 *  - 데이터 자동 저장/복원 (서버 재시작 시 이어짐)
 * 
 * 실행: node server.js
 * 접속: http://localhost:3000
 */

const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const { saveJSON, loadJSON, ensureDataDir } = require('./utils/file-io');
const companyData = require('./utils/company-data');
const hantoo = require('./crawlers/hantoo');
const archive = require('./utils/archive');
const macro = require('./crawlers/macro');
const prediction = require('./utils/prediction');
const gemini = require('./services/gemini');

// Puppeteer (현대차증권 JS렌더링용)
let puppeteer;
try {
  puppeteer = require('puppeteer-core');
  console.log('[Puppeteer] puppeteer-core 로드 성공');
} catch (e) {
  try {
    puppeteer = require('puppeteer');
    console.log('[Puppeteer] puppeteer 로드 성공');
  } catch (e2) {
    console.warn('[Puppeteer] 미설치 — 현대차증권 크롤링 비활성. npm install puppeteer-core 실행 필요');
  }
}

// Chrome/Edge 실행 경로 자동 탐지
function findChromePath() {
  const candidates = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    process.env.LOCALAPPDATA + '\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    '/usr/bin/google-chrome',
    '/usr/bin/chromium-browser',
    '/usr/bin/chromium'
  ].filter(Boolean);
  for (const p of candidates) {
    try { if (fs.existsSync(p)) return p; } catch (e) { }
  }
  return null;
}
const CHROME_PATH = findChromePath();

const app = express();
const PORT = config.PORT;
const DATA_DIR = config.DATA_DIR;

// ============================================================
// Express 미들웨어
// ============================================================
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-api-key, Authorization');
  res.setHeader('Access-Control-Max-Age', '86400');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// API 인증 미들웨어 — localhost 및 같은 사이트(프론트엔드) 요청 허용
app.use('/api', (req, res, next) => {
  // AI 전용 공간은 별도 인증 처리 — 기존 /claude, /gemini 경로도 포함
  if (req.path.startsWith('/claude') || req.path.startsWith('/gemini')) return next();
  const host = req.hostname || '';
  const isLocal = host === 'localhost' || host === '127.0.0.1' || host === '::1';
  if (isLocal) return next();
  // 같은 사이트에서 온 브라우저 요청 허용 (프론트엔드 페이지)
  const referer = req.headers.referer || req.headers.origin || '';
  if (referer.includes(host)) return next();
  // 외부 API 호출은 x-api-key 헤더 또는 api_key 쿼리 파라미터 필요
  const apiKey = req.headers['x-api-key'] || req.query.api_key;
  if (!apiKey || apiKey !== config.INTERNAL_API_KEY) {
    return res.status(401).json({ ok: false, error: '인증 필요: x-api-key 헤더를 확인하세요.' });
  }
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// 데이터 저장소 초기화
// ============================================================
const storedNews = loadJSON('news.json', []);
const sentItems = loadJSON('sent_items.json', {});
const reportCache = loadJSON('report_cache.json', {});
const reportAiCache = loadJSON('report_ai_cache.json', {});

const reportStores = {
  WiseReport: loadJSON('reports_wisereport.json', []),
  '미래에셋': loadJSON('reports_mirae.json', []),
  '하나증권': loadJSON('reports_hana.json', []),
  '현대차증권': loadJSON('reports_hyundai.json', []),
  '네이버': loadJSON('reports_naver.json', [])
};

// 하위호환: 기존 reports.json → 소스별 분배
const legacyReports = loadJSON('reports.json', []);
if (legacyReports.length > 0 && Object.values(reportStores).every(s => s.length === 0)) {
  legacyReports.forEach(r => {
    const src = r.source || '네이버';
    if (reportStores[src]) reportStores[src].push(r);
  });
  Object.entries(reportStores).forEach(([src, items]) => {
    if (items.length > 0) {
      const fname = src === 'WiseReport' ? 'reports_wisereport.json' : src === '미래에셋' ? 'reports_mirae.json' : 'reports_naver.json';
      saveJSON(fname, items);
    }
  });
  console.log(`[마이그레이션] 기존 리포트 ${legacyReports.length}건 → 소스별 분배 완료`);
}

function totalReportCount() {
  return Object.values(reportStores).reduce((sum, arr) => sum + arr.length, 0);
}

// 전송이력 정리
function cleanSentItems() {
  const cutoff = Date.now() - 7 * 24 * 3600000;
  let removed = 0;
  for (const key of Object.keys(sentItems)) {
    const val = sentItems[key];
    if (val === true || (typeof val === 'number' && val < cutoff)) {
      delete sentItems[key];
      removed++;
    }
  }
  if (removed > 0) {
    saveJSON('sent_items.json', sentItems);
    console.log(`[전송이력] ${removed}건 정리 (7일 경과), 잔여 ${Object.keys(sentItems).length}건`);
  }
}

// ============================================================
// 데이터 보존 규칙 적용 (매일 0:05 KST 실행)
// ============================================================
function cleanOldData() {
  const now = new Date();
  const kst = new Date(now.getTime() + 9 * 3600000);
  let totalCleaned = 0;

  // 1. news.json — 30일 이상 된 뉴스 삭제 (1000건 캡은 별도 유지)
  const newsCutoff = new Date(kst);
  newsCutoff.setDate(newsCutoff.getDate() - 30);
  const newsCutoffStr = newsCutoff.toISOString();
  const newsBefore = storedNews.length;
  // pubDate 또는 date 필드로 판단, 없으면 보존
  for (let i = storedNews.length - 1; i >= 0; i--) {
    const d = storedNews[i].pubDate || storedNews[i].date;
    if (d && new Date(d).toISOString() < newsCutoffStr) {
      storedNews.splice(i, 1);
    }
  }
  if (storedNews.length < newsBefore) {
    saveJSON('news.json', storedNews);
    const removed = newsBefore - storedNews.length;
    totalCleaned += removed;
    console.log(`[보존규칙] 뉴스 ${removed}건 삭제 (30일 경과), 잔여 ${storedNews.length}건`);
  }

  // 2. report_ai_cache.json — 60일 이상 (키: "종목|제목|날짜")
  const aiCacheCutoff = new Date(kst);
  aiCacheCutoff.setDate(aiCacheCutoff.getDate() - 60);
  const aiCutoffStr = aiCacheCutoff.toISOString().slice(0, 10).replace(/-/g, '.');
  let aiRemoved = 0;
  for (const key of Object.keys(reportAiCache)) {
    const parts = key.split('|');
    const dateStr = parts[2] || '';
    // 날짜 형식: "2026.02.20" 또는 "2026-02-20"
    if (dateStr && dateStr.replace(/-/g, '.') < aiCutoffStr) {
      delete reportAiCache[key];
      aiRemoved++;
    }
  }
  if (aiRemoved > 0) {
    saveJSON('report_ai_cache.json', reportAiCache);
    totalCleaned += aiRemoved;
    console.log(`[보존규칙] 리포트AI캐시 ${aiRemoved}건 삭제 (60일 경과), 잔여 ${Object.keys(reportAiCache).length}건`);
  }

  // 3. report_cache.json — 90일 이상 (값에 date 필드 있을 경우)
  const rcCutoff = new Date(kst);
  rcCutoff.setDate(rcCutoff.getDate() - 90);
  const rcCutoffMs = rcCutoff.getTime();
  let rcRemoved = 0;
  for (const key of Object.keys(reportCache)) {
    const val = reportCache[key];
    // 타임스탬프 또는 날짜 필드 확인
    if (typeof val === 'number' && val < rcCutoffMs) {
      delete reportCache[key];
      rcRemoved++;
    } else if (val && val.date && new Date(val.date).getTime() < rcCutoffMs) {
      delete reportCache[key];
      rcRemoved++;
    }
  }
  if (rcRemoved > 0) {
    saveJSON('report_cache.json', reportCache);
    totalCleaned += rcRemoved;
    console.log(`[보존규칙] 리포트캐시 ${rcRemoved}건 삭제 (90일 경과), 잔여 ${Object.keys(reportCache).length}건`);
  }

  // 4. news_ai_cache — 30일 (서버 메모리 + 파일)
  const newsAiCache = gemini.newsAiCacheServer;
  const naCutoff = new Date(kst);
  naCutoff.setDate(naCutoff.getDate() - 30);
  const naCutoffMs = naCutoff.getTime();
  let naRemoved = 0;
  for (const key of Object.keys(newsAiCache)) {
    const val = newsAiCache[key];
    if (val && val.date && new Date(val.date).getTime() < naCutoffMs) {
      delete newsAiCache[key];
      naRemoved++;
    }
  }
  if (naRemoved > 0) {
    saveJSON('news_ai_cache.json', newsAiCache);
    totalCleaned += naRemoved;
    console.log(`[보존규칙] 뉴스AI캐시 ${naRemoved}건 삭제 (30일 경과), 잔여 ${Object.keys(newsAiCache).length}건`);
  }

  // 5. dart_*.json — 7일 이상 된 DART 캐시 파일 삭제
  const dartCutoff = new Date(kst);
  dartCutoff.setDate(dartCutoff.getDate() - 7);
  const dartCutoffStr = dartCutoff.getUTCFullYear().toString() +
    String(dartCutoff.getUTCMonth() + 1).padStart(2, '0') +
    String(dartCutoff.getUTCDate()).padStart(2, '0');
  try {
    const files = fs.readdirSync(config.DATA_DIR).filter(f => f.startsWith('dart_') && f.endsWith('.json'));
    let dartRemoved = 0;
    for (const f of files) {
      const match = f.match(/dart_(\d{8})_/);
      if (match && match[1] < dartCutoffStr) {
        fs.unlinkSync(path.join(config.DATA_DIR, f));
        dartRemoved++;
      }
    }
    if (dartRemoved > 0) {
      totalCleaned += dartRemoved;
      console.log(`[보존규칙] DART캐시 ${dartRemoved}파일 삭제 (7일 경과)`);
    }
  } catch (e) {
    console.warn(`[보존규칙] DART 정리 실패: ${e.message}`);
  }

  // 6. 소스별 리포트 — 30일 보존 (companies/{code}/reports.json이 장기 보관)
  const reportCutoff = new Date(kst);
  reportCutoff.setDate(reportCutoff.getDate() - 30);
  const reportCutoffStr = reportCutoff.toISOString().slice(0, 10).replace(/-/g, '.');
  const reportFiles = {
    'reports_wisereport.json': reportStores.WiseReport,
    'reports_mirae.json': reportStores['미래에셋'],
    'reports_hana.json': reportStores['하나증권'],
    'reports_hyundai.json': reportStores['현대차증권'],
    'reports_naver.json': reportStores['네이버']
  };
  let reportRemoved = 0;
  for (const [fname, arr] of Object.entries(reportFiles)) {
    const before = arr.length;
    // 날짜 형식: "2026.02.20" 또는 "2026-02-20"
    for (let i = arr.length - 1; i >= 0; i--) {
      const d = (arr[i].date || '').replace(/-/g, '.');
      if (d && d < reportCutoffStr) {
        arr.splice(i, 1);
      }
    }
    if (arr.length < before) {
      saveJSON(fname, arr);
      reportRemoved += before - arr.length;
    }
  }
  if (reportRemoved > 0) {
    totalCleaned += reportRemoved;
    console.log(`[보존규칙] 소스별 리포트 ${reportRemoved}건 삭제 (30일 경과)`);
  }

  // 7. legacy reports.json 삭제 (마이그레이션 완료)
  try {
    const legacyFp = path.join(config.DATA_DIR, 'reports.json');
    if (fs.existsSync(legacyFp)) {
      const legacy = JSON.parse(fs.readFileSync(legacyFp, 'utf-8'));
      if (Array.isArray(legacy) && legacy.length > 0) {
        fs.unlinkSync(legacyFp);
        totalCleaned += legacy.length;
        console.log(`[보존규칙] legacy reports.json 삭제 (${legacy.length}건)`);
      }
    }
  } catch (e) { }

  if (totalCleaned > 0) {
    console.log(`[보존규칙] 총 ${totalCleaned}건 정리 완료`);
  }
}
cleanSentItems();

// 일시정지 제어
let isPaused = false;
let pausedAt = null;

// 주가 알림 메모리
const priceAlerts = [];

// 종목명으로 코드 찾기
function findStockCode(corpName) {
  const watchlist = hantoo.getWatchlist();
  const found = watchlist.find(s => s.name === corpName || corpName.includes(s.name));
  return found ? found.code : null;
}

console.log(`[복원] 뉴스 ${storedNews.length}건, 리포트 WR:${reportStores.WiseReport.length} 미래에셋:${reportStores['미래에셋'].length} 하나:${reportStores['하나증권'].length} 현대차:${reportStores['현대차증권'].length} 네이버:${reportStores['네이버'].length} (총${totalReportCount()}건), 전송이력 ${Object.keys(sentItems).length}건`);

// ============================================================
// Gemini 서비스 초기화
// ============================================================
gemini.init({
  reportAiCache,
  companyData,
  findStockCode,
});

// ============================================================
// Gemini API (프록시)
// ============================================================
app.post('/api/gemini', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: 'prompt 필수' });

  if (gemini.isCooldownActive()) {
    const remain = Math.max(0, Math.round((gemini.cooldownUntil - Date.now()) / 60000));
    return res.status(429).json({ error: `쿨다운 중 (${remain}분 후 해제)`, cooldown: true });
  }

  const model = gemini.getCurrentModel();
  const url = `${gemini.GEMINI_BASE}${model.id}:generateContent?key=${gemini.GEMINI_KEY}`;

  try {
    const resp = await axios.post(url, {
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.3, maxOutputTokens: 500 }
    }, { timeout: 30000, headers: { 'Content-Type': 'application/json' } });

    const text = resp.data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text || text.trim().length === 0) {
      gemini.demoteModel();
      return res.status(500).json({ error: '빈 응답', model: model.label });
    }

    gemini.markGeminiWork();
    resp.data._model = model.label;
    res.json(resp.data);
  } catch (e) {
    console.error(`[Gemini][${model.label}] ${e.message}`);
    gemini.demoteModel();
    res.status(e.response?.status || 500).json({ error: e.message, model: model.label });
  }
});

// ============================================================
// crawlers/reports 초기화
// ============================================================
const {
  init: initReports,
  fetchReportPage, fetchNaverReportDetail, fetchMiraeReportDetail,
  fetchHyundaiWithPuppeteer, fetchSourceReports, getSmartInterval,
  REPORT_SOURCES, scheduleNextFetch, startReportTimers,
  filterNaverDuplicates, getHyundaiBrowser, CHROME_PATH: REPORT_CHROME_PATH,
  puppeteer: reportPuppeteer
} = require('./crawlers/reports');

const reportTimers = {};

initReports({
  reportStores,
  reportCache,
  getIsPaused: () => isPaused,
  analyzeReportBatch: gemini.analyzeReportBatch
});

// ============================================================
// 아카이브 데이터 수집 헬퍼
// ============================================================
function getCollectedDataForArchive() {
  const watchlist = hantoo.getWatchlist();
  return {
    news: storedNews,
    reports: Object.values(reportStores).flat(),
    disclosures: [],
    prices: (() => {
      const result = {};
      for (const s of watchlist) {
        const p = companyData.getPrice(s.code);
        if (p.current) result[s.name] = p.current;
      }
      return result;
    })()
  };
}

// ============================================================
// app.locals에 공유 상태 주입
// ============================================================
app.locals.storedNews = storedNews;
app.locals.sentItems = sentItems;
app.locals.reportCache = reportCache;
app.locals.reportAiCache = reportAiCache;
app.locals.reportStores = reportStores;
app.locals.hantoo = hantoo;
app.locals.companyData = companyData;
app.locals.archive = archive;
app.locals.macro = macro;
app.locals.prediction = prediction;
app.locals.puppeteer = puppeteer;
app.locals.CHROME_PATH = CHROME_PATH;
app.locals.priceAlerts = priceAlerts;
app.locals.isPaused = isPaused;
app.locals.pausedAt = pausedAt;
app.locals.memoryWarningCount = 0;
app.locals.getCollectedDataForArchive = getCollectedDataForArchive;

// isPaused를 getter/setter로 설정 (라우트에서 변경 가능하도록)
Object.defineProperty(app.locals, 'isPaused', {
  get: () => isPaused,
  set: (val) => { isPaused = val; },
  enumerable: true
});
Object.defineProperty(app.locals, 'pausedAt', {
  get: () => pausedAt,
  set: (val) => { pausedAt = val; },
  enumerable: true
});

// 리포트 제어 함수 주입
app.locals.reportControl = {
  reportTimers,
  startReportTimers,
  REPORT_SOURCES,
  getSmartInterval,
};

// 컨텍스트 유틸 주입
const contextModule = require('./routes/context');
app.locals.contextHelpers = {
  loadContext: contextModule.loadContext,
  loadStockContext: contextModule.loadStockContext,
};
app.locals.hantoo = hantoo;

// ============================================================
// 라우트 등록
// ============================================================
app.use('/api', require('./routes/dart'));
app.use('/api', require('./routes/news'));

const reportsRoute = require('./routes/reports');
reportsRoute.init({
  filterNaverDuplicates,
  REPORT_SOURCES,
  fetchReportPage,
  fetchHyundaiWithPuppeteer,
  fetchSourceReports,
  getSmartInterval,
  getHyundaiBrowser,
});
app.use('/api', reportsRoute.router);

app.use('/api', require('./routes/stocks'));
app.use('/api', require('./routes/telegram'));

const backupRoute = require('./routes/backup');
app.use('/api', backupRoute.router);

app.use('/api', require('./routes/system'));
app.use('/api', contextModule.router);
app.use('/api', require('./routes/macro'));
app.use('/api', require('./routes/predictions'));
app.use('/api', require('./routes/data-viewer'));
app.use('/api', require('./routes/archive'));  // 아카이브 조회 (독립 모듈)

// AI 듀얼 공간 라우트 — 팩토리 패턴 (같은 코드, 통로만 분리)
const { createAiRoutes } = require('./routes/ai-space');
app.use('/api', createAiRoutes('claude'));   // → /api/claude/*
app.use('/api', createAiRoutes('gemini'));   // → /api/gemini/*

// ============================================================
// 프로세스 이벤트 처리
// ============================================================
process.on('SIGINT', async () => {
  console.log('[종료] 상태 저장 중...');
  gemini.saveServerState();
  hantoo.stop();
  if (getHyundaiBrowser()) { try { await getHyundaiBrowser().close(); } catch (e) { } }
  process.exit();
});

process.on('SIGBREAK', () => {
  console.log('[종료-BREAK] 상태 저장 중...');
  gemini.saveServerState();
});

process.on('exit', () => {
  try { gemini.saveServerState(); } catch (e) { }
});

// ============================================================
// 주가 알림 콜백
// ============================================================
hantoo.start();

hantoo.onPriceAlert((data) => {
  priceAlerts.unshift({
    ...data,
    id: Date.now(),
    timestamp: new Date().toISOString()
  });
  if (priceAlerts.length > 50) priceAlerts.length = 50;
  console.log(`[주가알림] ${data.name} ${data.change > 0 ? '+' : ''}${data.change}%`);
});

// ============================================================
// 1분 타이머 (메모리 감시, 쿨다운 감지, 아카이브)
// ============================================================
let last1701Reset = '';
let lastSentClean = '';
let memoryWarningCount = 0;

setInterval(() => {
  const { h, m } = gemini.getKSTHour();
  const today = new Date().toISOString().slice(0, 10);

  // 메모리 감시
  const memUsage = process.memoryUsage();
  const rssMB = Math.round(memUsage.rss / 1024 / 1024);

  if (rssMB > config.MEMORY_LIMIT_MB) {
    memoryWarningCount++;
    app.locals.memoryWarningCount = memoryWarningCount;
    console.warn(`[메모리] ⚠️ ${rssMB}MB 사용 (한도 ${config.MEMORY_LIMIT_MB}MB) — 경고 ${memoryWarningCount}/3`);
    if (memoryWarningCount >= 3) {
      console.error(`[메모리] 🔄 ${rssMB}MB — 한도 초과 3회 연속. 상태 저장 후 자동 재시작`);
      gemini.saveServerState();
      try { require('child_process').execSync('taskkill /f /im chrome.exe /fi "WINDOWTITLE eq about:blank" 2>nul'); } catch (e) { }
      process.exit(1);
    }
  } else {
    memoryWarningCount = 0;
    app.locals.memoryWarningCount = 0;
  }

  // 17:01 KST 프로 강제 리셋
  if (h === 17 && m >= 1 && m <= 3 && last1701Reset !== today) {
    last1701Reset = today;
    if (gemini.currentModelIndex > 0 || gemini.cooldownUntil > 0) {
      gemini.resetToPro('⏰ 17:01 KST 일일 리셋');
      if (!gemini.isAnalyzing) {
        triggerUnprocessedAnalysis('17:01 리셋');
      }
    }
  }

  // 매일 0:05 KST 전송이력 + 데이터 보존 규칙 정리
  if (h === 0 && m >= 5 && m <= 7 && lastSentClean !== today) {
    lastSentClean = today;
    cleanSentItems();
    cleanOldData();
  }

  // 매일 02:00 KST 아카이브 사이클
  if (h === 2 && m >= 0 && m <= 2) {
    const watchlist = hantoo.getWatchlist();
    archive.runArchiveCycle(getCollectedDataForArchive, watchlist, companyData);
  }

  // 쿨다운 해제 감지
  if (gemini.cooldownUntil > 0 && Date.now() >= gemini.cooldownUntil) {
    gemini.resetToPro('⏰ 쿨다운 해제');
    if (!gemini.isAnalyzing) {
      triggerUnprocessedAnalysis('쿨다운 해제');
    }
  }
}, 60000);

// 5분마다 상태 저장
setInterval(() => gemini.saveServerState(), 5 * 60000);

function triggerUnprocessedAnalysis(reason) {
  console.log(`[리포트AI] ${reason} → 미분석건 처리 시작`);
  analyzeUnprocessedReportsSafe().catch(e => console.error(`[리포트AI] 자동 분석 실패: ${e.message}`));
}

async function analyzeUnprocessedReportsSafe() {
  if (gemini.isAnalyzing) {
    console.log('[리포트AI] 이미 분석 중 — 미분석 처리 스킵');
    return;
  }
  if (gemini.isCooldownActive()) {
    console.log('[리포트AI] 쿨다운 중 — 미분석 처리 스킵');
    return;
  }

  const allReports = [];
  Object.values(reportStores).forEach(items => allReports.push(...items));

  const unprocessed = allReports.filter(r => {
    const cacheKey = `${r.corp}|${r.title}|${r.date}`;
    return !reportAiCache[cacheKey];
  });

  if (unprocessed.length === 0) {
    console.log('[리포트AI] 미분석 건 없음');
    return;
  }

  const batch = unprocessed.slice(0, 30);
  console.log(`[리포트AI] 미분석 ${unprocessed.length}건 중 ${batch.length}건 분석 시작...`);
  await gemini.analyzeReportBatch(batch);
}

// ============================================================
// 서버 시작
// ============================================================
app.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║   📊 DART 공시 모니터 서버 v3.5     ║');
  console.log(`  ║   🌐 http://localhost:${PORT}            ║`);
  console.log('  ║   ⏹  종료: Ctrl+C                   ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
  console.log(`  📁 데이터 경로: ${DATA_DIR}`);
  console.log(`  📰 저장된 뉴스: ${storedNews.length}건`);
  console.log(`  📊 리포트: WR:${reportStores.WiseReport.length} 미래에셋:${reportStores['미래에셋'].length} 하나:${reportStores['하나증권'].length} 현대차:${reportStores['현대차증권'].length} 네이버:${reportStores['네이버'].length}`);
  console.log(`  🤖 리포트AI 캐시: ${Object.keys(reportAiCache).length}건`);
  console.log(`  🤖 Gemini: ${gemini.GEMINI_MODELS[gemini.currentModelIndex]?.label} (${gemini.fallbackRound}회차)${gemini.isCooldownActive() ? ' [쿨다운중]' : ''}`);
  console.log(`  🌐 Puppeteer: ${puppeteer ? '✅ 로드됨' : '❌ 미설치'} | Chrome: ${CHROME_PATH || '❌ 미발견'}`);
  console.log('');
  console.log('  🔄 리포트 독립 수집 타이머 시작:');
  startReportTimers();

  // 아카이브 초기화
  try {
    archive.createDailySnapshot(getCollectedDataForArchive, hantoo.getWatchlist());
  } catch (e) {
    console.error(`[아카이브] 초기 스냅샷 실패: ${e.message}`);
  }
  console.log('  📦 아카이브 시스템 초기화 완료');

  // 워치리스트 종목 Context Tracker 자동 등록
  try {
    const watchlist = hantoo.getWatchlist();
    let autoAdded = 0;
    watchlist.forEach(s => {
      if (!s.code) return;
      if (!contextModule.loadStockContext(s.code)) {
        contextModule.saveStockContext(s.code, {
          code: s.code, name: s.name, pinned: false,
          price: null, change: null, lastDate: new Date().toISOString().slice(0, 10),
          context: '', nextAction: '',
          events: [], scenarios: [], keyInsights: [], history: []
        });
        autoAdded++;
      }
    });
    if (autoAdded > 0) console.log(`  🧠 Context Tracker: ${autoAdded}개 종목 자동 등록 (총 ${watchlist.length}개)`);
    else console.log(`  🧠 Context Tracker: ${watchlist.length}개 종목 등록 완료`);
  } catch (e) {
    console.error(`  ❌ Context 자동 등록 실패: ${e.message}`);
  }

  // 매크로 데이터 수집
  console.log('  🌍 매크로 데이터 수집 시작...');
  macro.fetchAllMacro().catch(e => console.error(`[매크로] 초기 수집 실패: ${e.message}`));
  setInterval(() => {
    macro.fetchAllMacro().catch(e => console.error(`[매크로] 수집 실패: ${e.message}`));
    const kstHour = new Date(Date.now() + 9 * 3600000).getUTCHours();
    if (kstHour === 6) {
      macro.verifyClosingPrices().catch(e => console.error(`[매크로] 종가 검증 실패: ${e.message}`));
    }
    if (kstHour === 3) macro.cleanOldDaily();
  }, 1800000);

  // 예측 피드백 루프
  console.log('  🎯 예측 피드백 루프 활성화');
  setInterval(() => {
    const kstHour = new Date(Date.now() + 9 * 3600000).getUTCHours();
    const kstMin = new Date(Date.now() + 9 * 3600000).getUTCMinutes();
    if (kstHour === 15 && kstMin >= 35 && kstMin <= 45) {
      const getPriceFn = (code) => {
        const watchlist = hantoo.getWatchlist();
        const stock = watchlist.find(s => s.code === code);
        return stock?.price ? parseFloat(stock.price) : null;
      };
      prediction.evaluateDuePredictions(getPriceFn);
    }
  }, 600000);

  console.log('');

  // 서버 시작 20초 후 미분석 리포트 처리
  setTimeout(() => {
    analyzeUnprocessedReportsSafe().catch(e => console.error(`[리포트AI] 초기 분석 실패: ${e.message}`));
  }, 20000);

  // 자동 백업 시작
  if (backupRoute.backupConfig.enabled) {
    backupRoute.startAutoBackup(() => app.locals);
  }
});
