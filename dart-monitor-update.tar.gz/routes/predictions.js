const express = require('express');
const router = express.Router();

// 예측 생성
router.post('/predictions', (req, res) => {
    const prediction = req.app.locals.prediction;
    try {
        const result = prediction.createPrediction(req.body);
        res.json({ ok: true, prediction: result });
    } catch (e) {
        res.status(400).json({ error: e.message });
    }
});

// 활성 예측 조회
router.get('/predictions', (req, res) => {
    const prediction = req.app.locals.prediction;
    const code = req.query.code || null;
    const active = prediction.getActivePredictions(code);
    res.json({ ok: true, predictions: active, total: active.length });
});

// 평가된 예측 조회
router.get('/predictions/evaluated', (req, res) => {
    const prediction = req.app.locals.prediction;
    const limit = parseInt(req.query.limit) || 50;
    const code = req.query.code || null;
    const evaluated = prediction.getEvaluatedPredictions(limit, code);
    res.json({ ok: true, predictions: evaluated, total: evaluated.length });
});

// 정확도 통계
router.get('/predictions/stats', (req, res) => {
    const prediction = req.app.locals.prediction;
    res.json({ ok: true, stats: prediction.getStats() });
});

// 수동 평가 실행
router.post('/predictions/evaluate', (req, res) => {
    const prediction = req.app.locals.prediction;
    const hantoo = req.app.locals.hantoo;
    try {
        const getPriceFn = (code) => {
            const watchlist = hantoo.getWatchlist();
            const stock = watchlist.find(s => s.code === code);
            return stock?.price ? parseFloat(stock.price) : null;
        };
        const result = prediction.evaluateDuePredictions(getPriceFn);
        res.json({ ok: true, result });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

module.exports = router;
