const express = require('express');
const axios = require('axios');
const config = require('../config');
const { saveJSON, loadJSON } = require('../utils/file-io');
const router = express.Router();

const DART_API_KEY = config.DART_API_KEY;

router.get('/dart', async (req, res) => {
    const { date, page } = req.query;
    if (!date) return res.status(400).json({ error: 'date 필수' });
    const p = page || 1;
    const url = `https://opendart.fss.or.kr/api/list.json?crtfc_key=${DART_API_KEY}&bgn_de=${date}&end_de=${date}&page_no=${p}&page_count=100`;

    try {
        const resp = await axios.get(url, { timeout: 15000 });
        if (resp.data && resp.data.list) {
            saveJSON(`dart_${date}_p${p}.json`, resp.data);
        }
        res.json(resp.data);
    } catch (e) {
        console.error(`[DART] ${e.message}`);
        const cached = loadJSON(`dart_${date}_p${p}.json`, null);
        if (cached) {
            console.log(`[DART] 캐시에서 복원: ${date} p${p}`);
            res.json(cached);
        } else {
            res.status(500).json({ error: e.message });
        }
    }
});

module.exports = router;
