/**
 * AI 듀얼 공간 라우트 — 팩토리 패턴
 * 
 * 목적: Claude/Gemini 각 AI에 동일한 통로(라우트)를 제공
 * 데이터: 공유 (기존 data 디렉토리 그대로 사용)
 * 인증: 각 AI 전용 키 + 관리자 키 허용
 * 권한: 매 요청마다 permissions 체크 후 허용/차단
 * 
 * 의존: config.js, utils/permissions.js만 사용
 */

const express = require('express');
const fs = require('fs');
const path = require('path');
const config = require('../config');
const permissions = require('../utils/permissions');

const DATA_DIR = config.DATA_DIR;
const CONTEXT_DIR = path.join(DATA_DIR, 'context');

// ============================================================
// AI 전용 인증 미들웨어 생성
// ============================================================
function createAiAuth(aiName) {
    // AI별 허용 키 결정
    const aiKeyMap = {
        claude: config.CLAUDE_API_KEY,
        gemini: config.GEMINI_API_KEY
    };
    const aiKey = aiKeyMap[aiName];

    return (req, res, next) => {
        // localhost는 허용 (개발 환경)
        const host = req.hostname || '';
        const isLocal = host === 'localhost' || host === '127.0.0.1' || host === '::1';
        if (isLocal) {
            req.aiName = aiName;
            return next();
        }

        // 같은 사이트 브라우저 요청 허용 (뷰어 페이지)
        const referer = req.headers.referer || req.headers.origin || '';
        if (referer.includes(host)) {
            req.aiName = aiName;
            return next();
        }

        // API 키 검증
        const apiKey = req.headers['x-api-key'] || req.query.api_key;
        if (!apiKey) {
            return res.status(401).json({ ok: false, error: `${aiName} API 키 필요` });
        }

        // 관리자 키는 모든 AI 공간 접근 가능
        if (apiKey === config.INTERNAL_API_KEY) {
            req.aiName = aiName;
            req.isAdmin = true;
            return next();
        }

        // AI 전용 키 검증
        if (apiKey === aiKey) {
            req.aiName = aiName;
            return next();
        }

        return res.status(403).json({ ok: false, error: `${aiName} 공간 접근 거부` });
    };
}

// ============================================================
// 권한 체크 헬퍼 — 차단 시 로그만 남기고 무시
// ============================================================
function requirePermission(section, action) {
    return (req, res, next) => {
        const ai = req.aiName;
        if (permissions.checkPermission(ai, section, action)) {
            return next();
        }
        console.log(`[권한차단] ${ai} — ${section}.${action} OFF`);
        return res.status(403).json({
            ok: false,
            error: `권한 없음: ${section}.${action}`,
            ai,
            blocked: true
        });
    };
}

// ============================================================
// 컨텍스트 유틸 (독립 구현 — context.js에 의존하지 않음)
// ============================================================
function loadContextFile(file) {
    const fp = path.join(CONTEXT_DIR, file);
    try {
        if (fs.existsSync(fp)) return JSON.parse(fs.readFileSync(fp, 'utf-8'));
    } catch (e) { }
    return null;
}

function saveContextFile(file, data) {
    if (!fs.existsSync(CONTEXT_DIR)) fs.mkdirSync(CONTEXT_DIR, { recursive: true });
    fs.writeFileSync(path.join(CONTEXT_DIR, file), JSON.stringify(data, null, 2), 'utf-8');
}

// 종목 컨텍스트 로드 — companies/{code}/context.json
function loadStockCtx(code) {
    const fp = path.join(DATA_DIR, 'companies', code, 'context.json');
    try {
        if (fs.existsSync(fp)) return JSON.parse(fs.readFileSync(fp, 'utf-8'));
    } catch (e) { }
    return null;
}

// 종목 컨텍스트 저장
function saveStockCtx(code, data) {
    const dir = path.join(DATA_DIR, 'companies', code);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'context.json'), JSON.stringify(data, null, 2), 'utf-8');
}

// JSON 파일 안전 로드
function loadJSON(file, fallback) {
    const fp = path.join(DATA_DIR, file);
    try {
        if (fs.existsSync(fp)) return JSON.parse(fs.readFileSync(fp, 'utf-8'));
    } catch (e) { }
    return fallback;
}

// ============================================================
// AI 라우트 팩토리 — claude/gemini 동일 구조 생성
// ============================================================
function createAiRoutes(aiName) {
    const router = express.Router();

    // 인증 미들웨어 적용
    router.use(createAiAuth(aiName));

    // ----------------------------------------------------------
    // 권한 테이블 조회/변경
    // ----------------------------------------------------------

    // 권한 테이블 조회 — AI가 입장 시 먼저 읽는 API (전체 API 가이드 포함)
    router.get(`/${aiName}/permissions`, (req, res) => {
        const data = permissions.loadPermissions(aiName);
        // API 가이드 — Claude가 사용 가능한 전체 경로와 파라미터
        const apiGuide = {
            _notice: '🚨 이 가이드를 반드시 읽고 아래 경로만 사용할 것. /api/context, /api/predictions 등 기존 경로 사용 금지.',
            auth: '모든 요청에 ?api_key=dartmonitor-claude 또는 헤더 x-api-key: dartmonitor-claude',
            read: {
                'GET /api/claude': '한방 조회 — 뉴스+공시+리포트+가격+매크로 전부 포함 (핵심 엔드포인트)',
                'GET /api/claude/ctx': '시장 요약 + 종목 컨텍스트 + commands',
                'GET /api/claude/news?limit=N': '최신 뉴스 (기본 30건, 읽기 전용)',
                'GET /api/claude/reports?limit=N': '리서치 리포트 (기본 30건, 읽기 전용)',
                'GET /api/claude/prices': '전 종목 현재가/등락률 (읽기 전용)',
                'GET /api/claude/dart': '최신 DART 공시 (읽기 전용)',
                'GET /api/claude/macro': '매크로 지표 — VIX, 환율, 국채금리 등 (읽기 전용)',
                'GET /api/claude/overseas': '미국시장 지표 (읽기 전용)',
                'GET /api/claude/commands': '미완료 사용자 명령 목록',
                'GET /api/claude/token': '한투 API 토큰 (읽기 전용)',
                'GET /api/claude/predictions': '예측 데이터',
                'GET /api/claude/stocks/:code/analysis': '종목별 AI 분석 결과',
                'GET /api/stocks/company/:code/price': '종목 일별 차트 + 시간외 가격 (인증 불필요)',
                'GET /api/consensus/:code': '종목별 컨센서스 (인증: ?api_key=dartmonitor-claude)'
            },
            write: {
                'POST /api/claude/ctx': { body: '{ market:{}, stocks:[{code,name,...}], insights:[], newsDigest:{} }', desc: '분석 결과 저장' },
                'POST /api/claude/archive': { body: '{ type, data }', desc: '아카이브 저장' },
                'POST /api/claude/predictions': { body: '{ predictions:[{code,name,...}] }', desc: '예측 저장 (종목코드+종목명 필수)' },
                'POST /api/claude/commands': { body: '{ text }', desc: '새 명령 추가' },
                'PATCH /api/claude/commands/:id': { body: '{ done:true, result }', desc: '명령 완료 처리' }
            },
            readOnly: '⚠️ news, reports, prices, dart, macro, overseas, token은 읽기 전용. POST 요청 불가 — 크롤러가 데이터를 수집하므로 덮어쓰기 금지.',
            retry: '⚠️ 502 에러 발생 시 2~3회 재시도할 것. Cloudflare 터널 간헐적 불안정이 원인.',
            workflow: [
                '1. 이 permissions 응답으로 사용 가능한 API 확인',
                '2. GET /api/claude/commands 로 미완료 명령 확인 → 있으면 우선 처리',
                '3. GET /api/claude/ctx 또는 GET /api/claude 로 현재 컨텍스트 읽기',
                '4. 필요 시 news, reports, prices, dart, macro 추가 조회 (읽기만 가능)',
                '5. 분석 완료 후 POST /api/claude/ctx 로 결과 저장'
            ]
        };
        res.json({ ok: true, apiGuide, ...data });
    });

    // 권한 테이블 변경 — 관리자 키만 가능
    router.post(`/${aiName}/permissions`, (req, res) => {
        const apiKey = req.headers['x-api-key'] || req.query.api_key;
        const host = req.hostname || '';
        const isLocal = host === 'localhost' || host === '127.0.0.1' || host === '::1';
        // 관리자 키 또는 로컬호스트만 변경 가능
        if (!isLocal && apiKey !== config.INTERNAL_API_KEY) {
            return res.status(403).json({ ok: false, error: '관리자만 권한 변경 가능' });
        }
        const current = permissions.loadPermissions(aiName);
        const updates = req.body.permissions || req.body;
        // 기존 권한에 업데이트 병합
        if (updates && typeof updates === 'object') {
            for (const section of Object.keys(updates)) {
                if (current.permissions[section]) {
                    Object.assign(current.permissions[section], updates[section]);
                }
            }
        }
        permissions.savePermissions(aiName, current);
        res.json({ ok: true, ...current });
    });

    // ----------------------------------------------------------
    // CTX — 시장 컨텍스트 읽기/쓰기
    // ----------------------------------------------------------

    // 컨텍스트 읽기 (시장 + 종목 + 명령어)
    router.get(`/${aiName}/ctx`, requirePermission('ctx', 'read'), (req, res) => {
        const market = loadContextFile('market.json') || { note: '', keyInsights: [], history: [] };
        const commands = loadContextFile('commands.json') || [];
        // 종목 컨텍스트 요약 목록
        const companiesDir = path.join(DATA_DIR, 'companies');
        let stocks = [];
        try {
            if (fs.existsSync(companiesDir)) {
                stocks = fs.readdirSync(companiesDir)
                    .filter(code => fs.existsSync(path.join(companiesDir, code, 'context.json')))
                    .map(code => {
                        try {
                            const d = JSON.parse(fs.readFileSync(path.join(companiesDir, code, 'context.json'), 'utf-8'));
                            return { code: d.code || code, name: d.name, pinned: d.pinned, lastDate: d.lastDate, price: d.price, change: d.change };
                        } catch (e) { return null; }
                    }).filter(Boolean);
            }
        } catch (e) { }
        // lastReadAt 업데이트
        if (permissions.checkPermission(aiName, 'ctx', 'updateLastRead')) {
            const meta = loadContextFile(`lastRead_${aiName}.json`) || {};
            meta.lastReadAt = new Date().toISOString();
            saveContextFile(`lastRead_${aiName}.json`, meta);
        }
        console.log(`[AI:${aiName}] CTX 읽기 — 시장:${market.lastDate || '-'} 종목:${stocks.length}개`);
        res.json({ ok: true, ai: aiName, commands, market, stocks });
    });

    // 컨텍스트 쓰기/저장
    router.post(`/${aiName}/ctx`, requirePermission('ctx', 'write'), (req, res) => {
        const { market, stocks, newsDigest, insights } = req.body;
        const results = [];
        const canSave = permissions.checkPermission(aiName, 'ctx', 'save');

        // 시장 컨텍스트 업데이트
        if (market) {
            if (!canSave) {
                results.push('market write OK but save blocked');
            } else {
                const prev = loadContextFile('market.json') || {};
                const merged = { ...prev, ...market, keyInsights: market.keyInsights || prev.keyInsights || [] };
                if (prev.lastDate && market.lastDate && prev.lastDate !== market.lastDate) {
                    merged.history = merged.history || [];
                    merged.history.push({ date: prev.lastDate, note: `KOSPI:${prev.kospi || '-'} ${(prev.keyInsights || []).slice(0, 2).join('; ')}`, auto: true });
                    if (merged.history.length > 30) merged.history = merged.history.slice(-30);
                }
                saveContextFile('market.json', merged);
                results.push('market updated');
            }
        }

        // 종목별 컨텍스트 업데이트
        if (stocks && Array.isArray(stocks)) {
            stocks.forEach(s => {
                if (!s.code) return;
                if (!canSave) { results.push(`stock ${s.code} write OK but save blocked`); return; }
                const prev = loadStockCtx(s.code) || {};
                const merged = { ...prev, ...s, keyInsights: s.keyInsights || prev.keyInsights || [] };
                if (prev.lastDate && s.lastDate && prev.lastDate !== s.lastDate) {
                    merged.history = merged.history || [];
                    merged.history.push({ date: prev.lastDate, note: `가격:${prev.price || '-'} ${(prev.keyInsights || []).slice(0, 2).join('; ')}`, auto: true });
                    if (merged.history.length > 30) merged.history = merged.history.slice(-30);
                }
                saveStockCtx(s.code, merged);
                results.push(`stock ${s.code} updated`);
            });
        }

        // 뉴스 다이제스트
        if (newsDigest) {
            if (!canSave) { results.push('newsDigest write OK but save blocked'); }
            else {
                const digest = loadContextFile('news_digest.json') || { latest: null, history: [] };
                if (digest.latest) { digest.history.unshift(digest.latest); if (digest.history.length > 14) digest.history = digest.history.slice(0, 14); }
                digest.latest = { ...newsDigest, savedAt: new Date().toISOString() };
                saveContextFile('news_digest.json', digest);
                results.push('newsDigest updated');
            }
        }

        // 인사이트 추가
        if (insights && Array.isArray(insights)) {
            if (!canSave) { results.push('insights write OK but save blocked'); }
            else {
                const m = loadContextFile('market.json') || {};
                m.keyInsights = m.keyInsights || [];
                insights.forEach(i => { if (!m.keyInsights.includes(i)) m.keyInsights.push(i); });
                if (m.keyInsights.length > 10) m.keyInsights = m.keyInsights.slice(-10);
                saveContextFile('market.json', m);
                results.push(`${insights.length} insights added`);
            }
        }

        console.log(`[AI:${aiName}] CTX 쓰기 — ${results.join(', ')}`);
        res.json({ ok: true, ai: aiName, results });
    });

    // ----------------------------------------------------------
    // ARC — 아카이브 읽기/저장
    // ----------------------------------------------------------
    const ARCHIVE_DIR = path.join(CONTEXT_DIR, 'archive');
    const ARCHIVE_TYPES = ['daily', 'weekly', 'monthly', 'quarterly', 'yearly', 'events'];

    // 아카이브 읽기
    router.get(`/${aiName}/archive`, requirePermission('arc', 'read'), (req, res) => {
        const type = req.query.type;
        const result = {};
        const types = type && ARCHIVE_TYPES.includes(type) ? [type] : ARCHIVE_TYPES;
        types.forEach(t => {
            const dir = path.join(ARCHIVE_DIR, t);
            if (fs.existsSync(dir)) {
                result[t] = fs.readdirSync(dir).filter(f => f.endsWith('.json')).sort().reverse().slice(0, 10).map(f => {
                    try { return { name: f, content: JSON.parse(fs.readFileSync(path.join(dir, f), 'utf-8')) }; }
                    catch (e) { return null; }
                }).filter(Boolean);
            } else {
                result[t] = [];
            }
        });
        console.log(`[AI:${aiName}] ARC 읽기 — ${types.join(',')}`);
        res.json({ ok: true, ai: aiName, archive: result });
    });

    // 아카이브 저장
    router.post(`/${aiName}/archive`, (req, res) => {
        const { type, data } = req.body;
        if (!type || !ARCHIVE_TYPES.includes(type)) {
            return res.status(400).json({ ok: false, error: `허용 타입: ${ARCHIVE_TYPES.join(', ')}` });
        }
        // 타입별 권한 체크
        const permMap = { daily: 'daily_save', weekly: 'weekly_save', monthly: 'monthly_save', events: 'event_save' };
        const perm = permMap[type] || 'daily_save';
        if (!permissions.checkPermission(aiName, 'arc', perm)) {
            console.log(`[권한차단] ${aiName} — arc.${perm} OFF`);
            return res.status(403).json({ ok: false, error: `권한 없음: arc.${perm}`, blocked: true });
        }
        const dir = path.join(ARCHIVE_DIR, type);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        const filename = req.body.filename || `${new Date().toISOString().slice(0, 10)}.json`;
        fs.writeFileSync(path.join(dir, filename), JSON.stringify(data, null, 2), 'utf-8');
        console.log(`[AI:${aiName}] ARC 저장 — ${type}/${filename}`);
        res.json({ ok: true, ai: aiName, type, filename });
    });

    // ----------------------------------------------------------
    // PRED — 예측 읽기/저장/평가
    // ----------------------------------------------------------

    // 예측 읽기
    router.get(`/${aiName}/predictions`, requirePermission('pred', 'read'), (req, res) => {
        const prediction = require('../utils/prediction');
        const code = req.query.code || null;
        const active = prediction.getActivePredictions(code);
        const stats = prediction.getStats();
        console.log(`[AI:${aiName}] PRED 읽기 — 활성:${active.length}건`);
        res.json({ ok: true, ai: aiName, predictions: active, stats });
    });

    // 예측 저장
    router.post(`/${aiName}/predictions`, requirePermission('pred', 'save'), (req, res) => {
        const prediction = require('../utils/prediction');
        try {
            const result = prediction.createPrediction(req.body);
            console.log(`[AI:${aiName}] PRED 저장 — ${result.code} ${result.direction}`);
            res.json({ ok: true, ai: aiName, prediction: result });
        } catch (e) {
            res.status(400).json({ ok: false, error: e.message });
        }
    });

    // 예측 평가 업데이트
    router.patch(`/${aiName}/predictions/:id`, requirePermission('pred', 'evaluate'), (req, res) => {
        // 예측 ID로 업데이트 (prediction 모듈에 위임)
        const prediction = require('../utils/prediction');
        try {
            const getPriceFn = (code) => {
                const hantoo = require('../crawlers/hantoo');
                const watchlist = hantoo.getWatchlist();
                const stock = watchlist.find(s => s.code === code);
                return stock?.price ? parseFloat(stock.price) : null;
            };
            const result = prediction.evaluateDuePredictions(getPriceFn);
            console.log(`[AI:${aiName}] PRED 평가 — ${JSON.stringify(result)}`);
            res.json({ ok: true, ai: aiName, result });
        } catch (e) {
            res.status(500).json({ ok: false, error: e.message });
        }
    });

    // ----------------------------------------------------------
    // STOCK — 종목 분석 읽기/저장
    // ----------------------------------------------------------

    // 종목 분석 읽기
    router.get(`/${aiName}/stocks/:code/analysis`, requirePermission('stock', 'read'), (req, res) => {
        const { code } = req.params;
        const ctx = loadStockCtx(code);
        if (!ctx) return res.status(404).json({ ok: false, error: '종목 없음' });
        // 가격 데이터도 같이 제공
        let priceData = null;
        try {
            const companyData = require('../utils/company-data');
            priceData = companyData.getPrice(code);
        } catch (e) { }
        console.log(`[AI:${aiName}] STOCK 읽기 — ${code}`);
        res.json({ ok: true, ai: aiName, code, context: ctx, price: priceData });
    });

    // 종목 분석 저장
    router.post(`/${aiName}/stocks/:code/analysis`, requirePermission('stock', 'save'), (req, res) => {
        const { code } = req.params;
        const prev = loadStockCtx(code) || {};
        const merged = { ...prev, ...req.body };
        // 히스토리 관리
        if (prev.lastDate && req.body.lastDate && prev.lastDate !== req.body.lastDate) {
            merged.history = merged.history || [];
            merged.history.push({
                date: prev.lastDate,
                note: `가격:${prev.price || '-'} ${(prev.keyInsights || []).slice(0, 2).join('; ')}`,
                auto: true
            });
            if (merged.history.length > 30) merged.history = merged.history.slice(-30);
        }
        saveStockCtx(code, merged);
        console.log(`[AI:${aiName}] STOCK 저장 — ${code}`);
        res.json({ ok: true, ai: aiName, code });
    });

    // ----------------------------------------------------------
    // TOKEN — 한투 토큰 (공유 읽기 전용, 항상 ON)
    // ----------------------------------------------------------

    // 한투 토큰 조회 — 항상 허용 (locked: true)
    router.get(`/${aiName}/token`, (req, res) => {
        const tokenData = loadJSON('hantoo_token.json', null);
        console.log(`[AI:${aiName}] TOKEN 읽기`);
        res.json({ ok: true, ai: aiName, token: tokenData });
    });

    // 한투 토큰 저장 금지 — 토큰 발급/갱신은 hantoo 크롤러가 전담
    // AI는 GET /token으로 읽기만 가능

    // ----------------------------------------------------------
    // NEWS — 뉴스 읽기 (서버 메모리의 storedNews 접근)
    // ----------------------------------------------------------
    router.get(`/${aiName}/news`, requirePermission('ctx', 'read'), (req, res) => {
        const storedNews = req.app.locals.storedNews || [];
        const limit = parseInt(req.query.limit) || 30;
        // 최근 뉴스를 역순(최신 먼저)으로
        const recent = storedNews.slice(-limit).reverse().map(n => ({
            title: n.title,
            source: n.source,
            date: n.date,
            link: n.link,
            cls: n.aiCls || '',
            importance: n.aiImportance || '',
            category: n.aiCategory || '',
            stocks: n.aiStocks || '',
            summary: n.aiSummary || ''
        }));
        // 뉴스 다이제스트도 같이 제공
        const digest = loadContextFile('news_digest.json') || { latest: null };
        console.log(`[AI:${aiName}] NEWS 읽기 — ${recent.length}건`);
        res.json({ ok: true, ai: aiName, news: recent, digest: digest.latest, total: storedNews.length });
    });

    // ----------------------------------------------------------
    // REPORTS — 리포트 읽기 (서버 메모리의 reportStores 접근)
    // ----------------------------------------------------------
    router.get(`/${aiName}/reports`, requirePermission('ctx', 'read'), (req, res) => {
        const reportStores = req.app.locals.reportStores || {};
        const limit = parseInt(req.query.limit) || 30;
        // 모든 소스의 리포트를 모아서 날짜순 정렬
        const allReports = [];
        Object.values(reportStores).forEach(items => allReports.push(...items));
        const sorted = allReports
            .sort((a, b) => (b.date || '').localeCompare(a.date || ''))
            .slice(0, limit)
            .map(r => ({
                title: r.title,
                source: r.source || r.broker || '',
                date: r.date,
                opinion: r.opinion || '',
                targetPrice: r.targetPrice || '',
                link: r.link || ''
            }));
        console.log(`[AI:${aiName}] REPORTS 읽기 — ${sorted.length}건`);
        res.json({ ok: true, ai: aiName, reports: sorted, total: allReports.length });
    });

    // ----------------------------------------------------------
    // PRICES — 실시간 주가 (watchlist 전체, 한투 크롤러 메모리)
    // ----------------------------------------------------------
    router.get(`/${aiName}/prices`, requirePermission('stock', 'read'), (req, res) => {
        const hantoo = req.app.locals.hantoo;
        if (!hantoo) return res.json({ ok: true, ai: aiName, prices: [] });
        const watchlist = hantoo.getWatchlist();
        const stockPrices = hantoo.getStockPrices();
        const companyData = req.app.locals.companyData;
        const prices = watchlist.map(s => {
            const p = stockPrices[s.code];
            let afterHours = null;
            try { afterHours = companyData?.getPrice(s.code)?.afterHours || p?.afterHours || null; } catch (e) { }
            return {
                code: s.code,
                name: s.name,
                sector: s.sector || '',
                price: p?.current?.price || p?.price || s.price || null,
                change: p?.current?.change || p?.change || null,
                changePct: p?.changePct || null,
                volume: p?.current?.volume || p?.volume || null,
                high: p?.current?.high || null,
                low: p?.current?.low || null,
                open: p?.current?.open || null,
                afterHours
            };
        });
        console.log(`[AI:${aiName}] PRICES 읽기 — ${prices.length}종목`);
        res.json({ ok: true, ai: aiName, prices, count: prices.length });
    });

    // ----------------------------------------------------------
    // DART — 오늘 DART 공시 조회
    // ----------------------------------------------------------
    router.get(`/${aiName}/dart`, requirePermission('ctx', 'read'), async (req, res) => {
        try {
            const axios = require('axios');
            const now = new Date();
            const kst = new Date(now.getTime() + 9 * 3600000);
            const yyyymmdd = kst.getUTCFullYear().toString() +
                String(kst.getUTCMonth() + 1).padStart(2, '0') +
                String(kst.getUTCDate()).padStart(2, '0');
            const dartRes = await axios.get('https://opendart.fss.or.kr/api/list.json', {
                params: {
                    crtfc_key: config.DART_API_KEY,
                    bgn_de: req.query.date || yyyymmdd,
                    end_de: req.query.date || yyyymmdd,
                    page_count: 100
                }, timeout: 8000
            });
            const disclosures = dartRes.data?.list || [];
            // 포트폴리오 관련만 필터링 (선택)
            const hantoo = req.app.locals.hantoo;
            let filtered = disclosures;
            if (req.query.filter === 'portfolio' && hantoo) {
                const names = hantoo.getWatchlist().map(s => s.name);
                filtered = disclosures.filter(d =>
                    names.some(n => d.corp_name === n || d.corp_name?.includes(n) || n.includes(d.corp_name))
                );
            }
            console.log(`[AI:${aiName}] DART 읽기 — 전체:${disclosures.length}건 필터:${filtered.length}건`);
            res.json({ ok: true, ai: aiName, disclosures: filtered, total: disclosures.length, date: yyyymmdd });
        } catch (e) {
            console.warn(`[AI:${aiName}] DART 조회 실패: ${e.message}`);
            res.json({ ok: true, ai: aiName, disclosures: [], error: e.message });
        }
    });

    // ----------------------------------------------------------
    // MACRO — 매크로 경제 데이터 읽기
    // ----------------------------------------------------------
    router.get(`/${aiName}/macro`, requirePermission('ctx', 'read'), (req, res) => {
        const macro = req.app.locals.macro;
        const overseas = loadJSON('overseas.json', { latest: null });
        const result = {
            current: macro?.getCurrent() || null,
            impact: macro?.getMarketImpactSummary() || null,
            overseas: overseas.latest
        };
        console.log(`[AI:${aiName}] MACRO 읽기`);
        res.json({ ok: true, ai: aiName, macro: result });
    });

    // ----------------------------------------------------------
    // OVERSEAS — 해외 시장 데이터 읽기
    // ----------------------------------------------------------
    router.get(`/${aiName}/overseas`, requirePermission('ctx', 'read'), (req, res) => {
        const overseas = loadJSON('overseas.json', { latest: null, history: [] });
        console.log(`[AI:${aiName}] OVERSEAS 읽기`);
        res.json({ ok: true, ai: aiName, overseas: overseas.latest, history: (overseas.history || []).slice(0, 5) });
    });

    // ----------------------------------------------------------
    // COMMANDS — 명령어 읽기/추가/완료
    // ----------------------------------------------------------

    // 명령어 목록 읽기
    router.get(`/${aiName}/commands`, requirePermission('ctx', 'read'), (req, res) => {
        const commands = loadContextFile('commands.json') || [];
        const pending = commands.filter(c => !c.done);
        console.log(`[AI:${aiName}] COMMANDS 읽기 — 전체:${commands.length} 미완료:${pending.length}`);
        res.json({ ok: true, ai: aiName, commands, pending });
    });

    // 명령어 추가
    router.post(`/${aiName}/commands`, requirePermission('ctx', 'write'), (req, res) => {
        const commands = loadContextFile('commands.json') || [];
        const { text, priority } = req.body;
        if (!text) return res.status(400).json({ ok: false, error: '명령어 텍스트 필요' });
        const newCmd = {
            id: Date.now().toString(),
            text,
            priority: priority || 'normal',
            createdAt: new Date().toISOString(),
            createdBy: aiName,
            done: false
        };
        commands.push(newCmd);
        saveContextFile('commands.json', commands);
        console.log(`[AI:${aiName}] COMMANDS 추가 — "${text}"`);
        res.json({ ok: true, ai: aiName, command: newCmd });
    });

    // 명령어 완료 처리
    router.patch(`/${aiName}/commands/:id`, requirePermission('ctx', 'write'), (req, res) => {
        const commands = loadContextFile('commands.json') || [];
        const cmd = commands.find(c => c.id === req.params.id);
        if (!cmd) return res.status(404).json({ ok: false, error: '명령어 없음' });
        cmd.done = true;
        cmd.doneAt = new Date().toISOString();
        cmd.doneBy = aiName;
        if (req.body.result) cmd.result = req.body.result;
        saveContextFile('commands.json', commands);
        console.log(`[AI:${aiName}] COMMANDS 완료 — "${cmd.text}"`);
        res.json({ ok: true, ai: aiName, command: cmd });
    });

    return router;
}

module.exports = { createAiRoutes };
