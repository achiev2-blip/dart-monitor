# dartmonitor.com — AI 듀얼 공간 구축 명세서 v3 (최종)
## 작성: 2026-02-23 | 목적: 안티 개발 의뢰용

---

## 1. 개요

구름이(Claude)와 제미나이(Gemini) 두 AI가 dartmonitor.com에서
각자 독립된 공간을 갖고 분석·예측·저장 작업을 수행한다.
아빠가 `/admin` 전용 페이지에서 각 시트의 버튼/기능 단위로 ON/OFF 제어한다.
AI는 시트 입장 시 권한 테이블을 먼저 읽고, 허용된 기능만 실행한다.

---

## 2. 전체 구조

```
dartmonitor.com/
├── admin/               ← 아빠 전용 관리자 페이지 (권한 제어판)
│
├── claude/              ← 구름이(Claude) 전용 공간
│   ├── ctx
│   ├── arc
│   ├── pred
│   └── stock
│
└── gemini/              ← 제미나이(Gemini) 전용 공간
    ├── ctx
    ├── arc
    ├── pred
    └── stock
```

---

## 3. API 키

| 주체 | API 키 | 접근 범위 |
|------|--------|----------|
| 아빠 (관리자) | `dartmonitor-2024` | 전체 + /admin |
| 구름이 (Claude) | `dartmonitor-claude` | /claude/* 전용 |
| 제미나이 (Gemini) | `dartmonitor-gemini` | /gemini/* 전용 |

---

## 4. /admin 관리자 페이지

### 4-1. 접근
```
URL: dartmonitor.com/admin/
인증: dartmonitor-2024 키만 접근 가능
```

### 4-2. 화면 구조
```
/admin/
├── [구름이 탭] [제미나이 탭]
│
├── CTX 섹션
│   ├── 시장요약 읽기      [ON/OFF]
│   ├── 시장요약 쓰기      [ON/OFF]
│   ├── 시장요약 저장      [ON/OFF]
│   ├── 컨텍스트 분석      [ON/OFF]
│   └── lastReadAt 업데이트 [ON/OFF]
│
├── ARC 섹션
│   ├── 일별 읽기          [ON/OFF]
│   ├── 일별 저장          [ON/OFF]
│   ├── 주간 읽기          [ON/OFF]
│   ├── 주간 저장          [ON/OFF]
│   ├── 월간 읽기          [ON/OFF]
│   ├── 월간 저장          [ON/OFF]
│   ├── 이벤트 읽기        [ON/OFF]
│   ├── 이벤트 저장        [ON/OFF]
│   └── 자동 요약 생성     [ON/OFF]
│
├── PRED 섹션
│   ├── 예측 읽기          [ON/OFF]
│   ├── 예측 입력          [ON/OFF]
│   ├── 예측 저장          [ON/OFF]
│   ├── 평가 업데이트      [ON/OFF]
│   └── 자동 분석          [ON/OFF]
│
├── STOCK 섹션
│   ├── 종목 분석 읽기     [ON/OFF]
│   ├── 종목 분석 쓰기     [ON/OFF]
│   ├── 종목 분석 저장     [ON/OFF]
│   ├── 메모 입력          [ON/OFF]
│   ├── 시그널 입력        [ON/OFF]
│   └── 자동 분석          [ON/OFF]
│
└── 한투 토큰 섹션
    ├── 토큰 읽기          🔒 고정 ON
    ├── 토큰 저장          🔒 고정 ON
    └── 자동 갱신          🔒 고정 ON
```

> ⚠️ 한투(한국투자증권) 토큰은 주가 데이터의 근간. UI에서 ON/OFF 버튼 비표시. 잠금 아이콘만 표시.

---

## 5. AI 동작 흐름

### 5-1. 시트 입장 시
```
시트 입장
    ↓
GET /api/{ai}/permissions  ← 권한 테이블 읽기
    ↓
허용된 기능만 활성화
차단된 기능은 실행 안 함 (에러 없이 무시)
    ↓
작업 시작
```

### 5-2. 버튼/기능 실행 시
```
기능 실행 요청
    ↓
권한 테이블 재확인
    ↓
ON → 실행
OFF → 차단 (로그만 남김)
```

### 5-3. 저장 분리 원칙
- **쓰기 ON + 저장 OFF** → 분석은 하되 아빠 확인 전 저장 불가
- 아빠가 확인 후 "저장해" 지시 → 저장 ON → 저장 실행
- 실수로 덮어쓰는 것 방지

---

## 6. 권한 테이블 데이터 구조

```json
{
  "ai": "claude | gemini",
  "updatedAt": "2026-02-23T22:00:00+09:00",
  "permissions": {
    "ctx": {
      "read":         true,
      "write":        true,
      "save":         true,
      "analyze":      true,
      "updateLastRead": true
    },
    "arc": {
      "read":         true,
      "daily_save":   true,
      "weekly_save":  true,
      "monthly_save": true,
      "event_save":   true,
      "auto_summary": true
    },
    "pred": {
      "read":         true,
      "input":        true,
      "save":         true,
      "evaluate":     true,
      "analyze":      true
    },
    "stock": {
      "read":         true,
      "write":        true,
      "save":         true,
      "memo":         true,
      "signal":       true,
      "analyze":      true
    },
    "hantooToken": {
      "read":         true,
      "save":         true,
      "autoRenew":    true,
      "locked":       true
    }
  }
}
```

---

## 7. 엔드포인트 명세

```
# 권한 관리
GET    /api/{ai}/permissions              → 권한 테이블 조회
POST   /api/{ai}/permissions              → 권한 변경 (아빠 키만 가능)

# CTX
GET    /api/{ai}/ctx                      → 읽기
POST   /api/{ai}/ctx                      → 쓰기/저장

# ARC
GET    /api/{ai}/archive                  → 읽기
POST   /api/{ai}/archive                  → 저장

# PRED
GET    /api/{ai}/predictions              → 목록 읽기
POST   /api/{ai}/predictions              → 예측 저장
PATCH  /api/{ai}/predictions/{id}         → 평가 업데이트

# STOCK
GET    /api/{ai}/stocks/{코드}/analysis   → 읽기
POST   /api/{ai}/stocks/{코드}/analysis   → 저장

# 한투 토큰
GET    /api/{ai}/token                    → 조회 (항상 ON)
POST   /api/{ai}/token                    → 저장 (항상 ON)
```

---

## 8. 공유 데이터 (두 AI 공통 읽기 전용)

| 항목 | 엔드포인트 | 쓰기 |
|------|-----------|------|
| 뉴스 | `/api/news` | 아빠만 |
| 공시 | `/api/dart` | 아빠만 |
| 리포트 | `/api/reports` | 아빠만 |
| 종목 가격 | `/api/stocks/company/{코드}/price` | — |
| 미국 시장 | `us_market.html` | — |

---

## 9. 뷰어 화면

```
dartmonitor.com/claude/   → 구름이 공간 (CTX/ARC/PRED/STOCK 탭)
dartmonitor.com/gemini/   → 제미나이 공간 (동일 구조)
dartmonitor.com/compare/  → 두 AI 예측 비교 (선택)
dartmonitor.com/admin/    → 아빠 전용 권한 제어판
```

---

## 10. 구현 우선순위

| 순위 | 항목 |
|------|------|
| 1 | API 키 3개 설정 (admin / claude / gemini) |
| 2 | /api/claude/* 라우트 전체 구현 |
| 3 | /api/gemini/* 라우트 전체 구현 (동일 구조 복사) |
| 4 | 권한 테이블 API (GET/POST /permissions) |
| 5 | /admin 페이지 — 탭·섹션·ON/OFF 버튼 UI |
| 6 | 한투 토큰 고정 ON + 잠금 UI |
| 7 | AI 시트 입장 시 권한 자동 체크 로직 |
| 8 | 뷰어 화면 분리 (/claude/ /gemini/) |
| 9 | 비교 뷰어 (/compare/) |

---

## 11. 기존 데이터 이전

- 현재 ARC 데이터 → `claude/` 공간으로 이전
- 현재 PRED 데이터 → `claude/` 공간으로 이전
- 기존 `dartmonitor-2024` 키 → 아빠 관리자 키로 유지

---

## 변경 이력

| 버전 | 날짜 | 내용 |
|------|------|------|
| v1 | 2026-02-23 | 초판. 듀얼 AI 공간 구조 |
| v2 | 2026-02-23 | 권한 4개(읽기/쓰기/저장/분석) + 한투 고정 ON |
| v3 | 2026-02-23 | 시트별 버튼 단위 세밀 제어 + /admin 별도 페이지 + AI 입장 시 권한 체크 로직 추가. 최종 확정 |
